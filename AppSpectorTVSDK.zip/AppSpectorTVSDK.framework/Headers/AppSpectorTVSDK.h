//
//  AppSpectorTVSDK.h
//  AppSpectorTVSDK
//
//  Created by Deszip on 21/06/2018.
//  Copyright © 2018 Techery. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double AppSpectorTVSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AppSpectorTVSDKVersionString[];

#import "AppSpector.h"
