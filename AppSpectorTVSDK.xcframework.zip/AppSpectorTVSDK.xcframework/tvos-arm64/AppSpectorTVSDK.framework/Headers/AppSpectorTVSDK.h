//
//  AppSpectorTVSDK.h
//  AppSpectorTVSDK
//
//  Created by Deszip on 21/06/2018.
//  Copyright © 2018 Techery. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AppSpectorTVSDK/AppSpector.h>
